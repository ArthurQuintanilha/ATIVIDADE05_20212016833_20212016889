export class Foto {
  id: number;
  imagem: string;
  data: string;
  idArvore: number;

  constructor(){
    this.id = 0;
    this.imagem = '';
    this.data = '';
    this.idArvore = 0;
  }
}
