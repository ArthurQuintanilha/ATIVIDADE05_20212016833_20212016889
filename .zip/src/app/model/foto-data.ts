export class FotoData {
  webPath: any;
  constructor(){
    this.webPath = ""
  }
}
