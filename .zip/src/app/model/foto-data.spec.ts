import { FotoData } from './foto-data';

describe('FotoData', () => {
  it('should create an instance', () => {
    expect(new FotoData()).toBeTruthy();
  });
});
