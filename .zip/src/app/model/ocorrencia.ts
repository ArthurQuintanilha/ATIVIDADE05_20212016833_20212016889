export class Ocorrencia {
  id: number;
  descricao: string;
  data: string;
  idArvore: number;

  constructor(){
    this.id = 0;
    this.descricao = "";
    this.data = "";
    this.idArvore = 0;
  }
}

