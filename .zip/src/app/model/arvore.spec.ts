import { Arvore } from '../model/arvore';

describe('Arvore', () => {
  it('should create an instance', () => {
    expect(new Arvore()).toBeTruthy();
  });
});
