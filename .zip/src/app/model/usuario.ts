export class Usuario {
    id: number;
    email: string;
    senha: string;
    nome: string; 
  
    constructor(){
        this.id = 0;
        this.email = '';
        this.senha = '';
        this.nome = '';
    }
  }
  