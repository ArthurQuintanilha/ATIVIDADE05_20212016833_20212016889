export interface IFoto{
  webPath: any;

}
