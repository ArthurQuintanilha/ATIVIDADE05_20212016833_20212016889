import { Ocorrencia } from './ocorrencia';

describe('Ocorrencia', () => {
  it('should create an instance', () => {
    expect(new Ocorrencia()).toBeTruthy();
  });
});
