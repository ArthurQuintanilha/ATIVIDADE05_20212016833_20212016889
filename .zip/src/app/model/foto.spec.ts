import { Foto } from './foto';

describe('Foto', () => {
  it('should create an instance', () => {
    expect(new Foto()).toBeTruthy();
  });
});
